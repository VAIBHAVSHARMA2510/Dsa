package com.movie.model;

import jakarta.persistence.*;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;

    // ============================================
    // FOREIGN KEY RELATIONSHIP (Booking -> Movie)
    // Many Bookings can belong to One Movie.
    // @JoinColumn creates the "movie_id" FK column
    // inside the "bookings" table referencing
    // the "id" primary key of the "movies" table.
    // ============================================
    @ManyToOne
    @JoinColumn(name = "movie_id", referencedColumnName = "id")
    private Movie movie;

    private Integer seatsBooked;
    private Double totalPrice;

    public Booking() {
    }

    public Booking(String username, Movie movie, Integer seatsBooked, Double totalPrice) {
        this.username = username;
        this.movie = movie;
        this.seatsBooked = seatsBooked;
        this.totalPrice = totalPrice;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Integer getSeatsBooked() {
        return seatsBooked;
    }

    public void setSeatsBooked(Integer seatsBooked) {
        this.seatsBooked = seatsBooked;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
