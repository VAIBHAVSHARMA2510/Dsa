package com.movie.controller;

import com.movie.model.Movie;
import com.movie.repository.MovieRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class MovieController {

    @Autowired
    private MovieRepository movieRepo;

    private String getUser(HttpSession session) {
        return (String) session.getAttribute("username");
    }

    // View all movies
    @GetMapping("/movies")
    public String viewMovies(HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        model.addAttribute("movies", movieRepo.findAll());
        model.addAttribute("username", getUser(session));
        return "movies";
    }

    // Show Add Movie form
    @GetMapping("/movies/add")
    public String addMovieForm(HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        model.addAttribute("movie", new Movie());
        model.addAttribute("username", getUser(session));
        return "addmovie";
    }

    // Save new movie
    @PostMapping("/movies/save")
    public String saveMovie(@ModelAttribute Movie movie, HttpSession session) {
        if (getUser(session) == null) return "redirect:/login";

        movieRepo.save(movie);
        return "redirect:/movies";
    }

    // Show Edit Movie form
    @GetMapping("/movies/edit/{id}")
    public String editMovieForm(@PathVariable Long id, HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        Movie movie = movieRepo.findById(id).orElseThrow();
        model.addAttribute("movie", movie);
        model.addAttribute("username", getUser(session));
        return "editmovie";
    }

    // Delete movie
    @GetMapping("/movies/delete/{id}")
    public String deleteMovie(@PathVariable Long id, HttpSession session) {
        if (getUser(session) == null) return "redirect:/login";

        movieRepo.deleteById(id);
        return "redirect:/movies";
    }
}
