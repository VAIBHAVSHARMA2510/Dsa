package com.movie.controller;

import com.movie.model.Movie;
import com.movie.repository.BookingRepository;
import com.movie.repository.MovieRepository;
import com.movie.service.BookingService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class BookingController {

    @Autowired
    private MovieRepository movieRepo;

    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private BookingService bookingService;

    private String getUser(HttpSession session) {
        return (String) session.getAttribute("username");
    }

    // Show booking form for selected movie
    @GetMapping("/book/{id}")
    public String showBookForm(@PathVariable Long id, HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        Movie movie = movieRepo.findById(id).orElseThrow();
        model.addAttribute("movie", movie);
        model.addAttribute("username", getUser(session));
        return "bookform";
    }

    // Process booking
    @PostMapping("/confirmbooking")
    public String confirmBooking(@RequestParam Long movieId,
                                  @RequestParam int seats,
                                  HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        String message = bookingService.bookTickets(getUser(session), movieId, seats);

        model.addAttribute("message", message);
        model.addAttribute("username", getUser(session));
        model.addAttribute("movies", movieRepo.findAll());
        return "movies";
    }

    // View my bookings only — note: booking.getMovie() uses the FK
    // relationship to fetch the related Movie's title directly.
    @GetMapping("/mybookings")
    public String myBookings(HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        String username = getUser(session);
        model.addAttribute("bookings", bookingRepo.findByUsername(username));
        model.addAttribute("username", username);
        return "mybookings";
    }
}
