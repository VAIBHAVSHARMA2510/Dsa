package com.movie.service;

import com.movie.model.Booking;
import com.movie.model.Movie;
import com.movie.repository.BookingRepository;
import com.movie.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    @Autowired
    private MovieRepository movieRepo;

    @Autowired
    private BookingRepository bookingRepo;

    public String bookTickets(String username, Long movieId, int seats) {

        Movie movie = movieRepo.findById(movieId).orElseThrow();

        // TRICKY LOGIC #1: Check seat availability
        if (movie.getAvailableSeats() < seats) {
            return "Booking Failed! Only " + movie.getAvailableSeats() + " seats available.";
        }

        // TRICKY LOGIC #2: Reduce available seats on the Movie (parent table)
        movie.setAvailableSeats(movie.getAvailableSeats() - seats);
        movieRepo.save(movie);

        // TRICKY LOGIC #3: Auto-calculate total price
        double total = movie.getTicketPrice() * seats;

        // TRICKY LOGIC #4: Set the FOREIGN KEY by assigning the
        // actual Movie object (not just an ID/String) to the Booking.
        // JPA automatically stores movie.getId() into the movie_id
        // FK column of the bookings table.
        Booking booking = new Booking();
        booking.setUsername(username);
        booking.setMovie(movie);
        booking.setSeatsBooked(seats);
        booking.setTotalPrice(total);
        bookingRepo.save(booking);

        return "Booking Successful! Total: Rs " + total;
    }
}
