# Movie Management System
Spring Boot MVC + Spring Data JPA + Thymeleaf
**With a real Foreign Key relationship between `bookings` and `movies`.**

## How to Import & Run

### Option A: IntelliJ IDEA / Eclipse / STS
1. Unzip this folder.
2. Open your IDE → File → Open / Import → select the `movie-management-system` folder
   (IDE will detect it as a Maven project via `pom.xml`).
3. Let Maven download dependencies (first time only, needs internet).
4. Edit `src/main/resources/application.properties` if your MySQL
   username/password is different from `root` / `root`.
5. Run `MovieManagementSystemApplication.java` (right-click → Run).
6. Open browser → http://localhost:8080

### Before running — Setup MySQL
- Make sure MySQL server is running.
- The app will auto-create the `moviedb` database and tables, **including
  the foreign key** (`spring.jpa.hibernate.ddl-auto=update` +
  `createDatabaseIfNotExist=true`).
- To add sample login/movie/booking data, run `database-setup.sql` in
  MySQL Workbench / CLI before or after first run.

## Login Credentials (after running database-setup.sql)
- username: `admin`   password: `admin123`
- username: `vaibhav` password: `pass123`

## Project Structure
```
src/main/java/com/movie/
├── MovieManagementSystemApplication.java
├── controller/
│   ├── AuthController.java      (login, logout)
│   ├── MovieController.java     (CRUD: list/add/edit/delete movies)
│   └── BookingController.java   (book tickets, my bookings)
├── model/
│   ├── User.java
│   ├── Movie.java                (PARENT table — referenced by FK)
│   └── Booking.java              (CHILD table — holds the FK: movie_id)
├── repository/
│   ├── UserRepository.java
│   ├── MovieRepository.java
│   └── BookingRepository.java
└── service/
    └── BookingService.java      (seat check, deduction, price calc, FK set)

src/main/resources/
├── templates/
│   ├── login.html
│   ├── movies.html
│   ├── addmovie.html
│   ├── editmovie.html
│   ├── bookform.html
│   └── mybookings.html
└── application.properties
```

## ⭐ How the Foreign Key Relation Works

`Booking.java` has:
```java
@ManyToOne
@JoinColumn(name = "movie_id", referencedColumnName = "id")
private Movie movie;
```

This tells Hibernate/JPA: "Many Bookings can point to **one** Movie."
It automatically creates a `movie_id` column in the `bookings` table
that is a **FOREIGN KEY** referencing the `id` column of the `movies`
table (see `database-setup.sql` for the exact `FOREIGN KEY (movie_id)
REFERENCES movies(id)` SQL Hibernate generates).

When saving a booking in `BookingService.java`, we assign the **whole
Movie object** (not just an ID) to `booking.setMovie(movie)` — JPA
takes care of storing the correct `movie_id` value for us.

When displaying "My Bookings" in `mybookings.html`, we directly access
`b.movie.title` and `b.movie.genre` — Thymeleaf/JPA automatically
follows the FK relationship to fetch the related Movie's details.

## Feature Flow
```
/login → POST → session set → /movies
/movies → list all movies (+ Add/Edit/Delete for admin)
/movies/add → POST /movies/save → new movie saved
/movies/edit/{id} → POST /movies/save → movie updated
/movies/delete/{id} → movie deleted
/book/{id} → enter tickets → POST /confirmbooking
   (checks seat availability, deducts seats, calculates total,
    sets FK movie_id via booking.setMovie(movie))
/mybookings → shows only logged-in user's bookings (movie title via FK)
/logout → session.invalidate() → /login
```

## Tricky Logic Implemented
1. Foreign Key relation: `Booking.movie` (@ManyToOne) → `Movie.id`
2. Seat availability check before booking (BookingService)
3. Seat count auto-reduced after successful booking
4. Total price auto-calculated (ticketPrice × seats)
5. "Sold Out" shown in UI when seats = 0
6. My Bookings filtered by logged-in username (not all bookings)
7. Full CRUD on Movie (Add/Edit/Delete/List)
8. Session check (redirect to login) on every protected page
