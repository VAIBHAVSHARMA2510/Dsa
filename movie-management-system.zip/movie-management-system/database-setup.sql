-- ============================================
-- Movie Management System - Database Setup
-- ============================================
-- NOTE: spring.jpa.hibernate.ddl-auto=update will
-- auto-create these tables (including the Foreign
-- Key) when you run the application for the first
-- time. This script is provided in case you want to
-- create the DB and insert sample data manually.
-- ============================================

CREATE DATABASE IF NOT EXISTS moviedb;
USE moviedb;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(30),
    password VARCHAR(30)
);

CREATE TABLE IF NOT EXISTS movies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100),
    genre VARCHAR(50),
    language VARCHAR(30),
    ticket_price DOUBLE,
    available_seats INT
);

-- bookings.movie_id is a FOREIGN KEY referencing movies.id
-- (Many bookings -> One movie)
CREATE TABLE IF NOT EXISTS bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(30),
    movie_id INT,
    seats_booked INT,
    total_price DOUBLE,
    CONSTRAINT fk_movie
        FOREIGN KEY (movie_id) REFERENCES movies(id)
);

-- Sample Data
INSERT INTO users (username, password) VALUES ('admin', 'admin123');
INSERT INTO users (username, password) VALUES ('vaibhav', 'pass123');

INSERT INTO movies (title, genre, language, ticket_price, available_seats)
VALUES ('Pathaan', 'Action', 'Hindi', 250.00, 100);

INSERT INTO movies (title, genre, language, ticket_price, available_seats)
VALUES ('Avengers Endgame', 'Sci-Fi', 'English', 300.00, 50);

INSERT INTO movies (title, genre, language, ticket_price, available_seats)
VALUES ('KGF Chapter 2', 'Action', 'Kannada', 200.00, 0);

-- Sample booking (demonstrates FK: movie_id = 1 -> Pathaan)
INSERT INTO bookings (username, movie_id, seats_booked, total_price)
VALUES ('vaibhav', 1, 2, 500.00);
