-- ============================================
-- Airline Booking System - Database Setup
-- ============================================
-- NOTE: spring.jpa.hibernate.ddl-auto=update will
-- auto-create these tables when you run the app.
-- This script is provided in case you want to
-- create the DB and insert sample data manually
-- BEFORE running the application.
-- ============================================

CREATE DATABASE IF NOT EXISTS airlinedb;
USE airlinedb;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(30),
    password VARCHAR(30)
);

CREATE TABLE IF NOT EXISTS flights (
    id INT PRIMARY KEY AUTO_INCREMENT,
    flight_number VARCHAR(20),
    source VARCHAR(30),
    destination VARCHAR(30),
    price DOUBLE,
    available_seats INT
);

CREATE TABLE IF NOT EXISTS bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(30),
    flight_number VARCHAR(20),
    seats_booked INT,
    total_price DOUBLE
);

-- Sample Data
INSERT INTO users (username, password) VALUES ('admin', 'admin123');
INSERT INTO users (username, password) VALUES ('vaibhav', 'pass123');

INSERT INTO flights (flight_number, source, destination, price, available_seats)
VALUES ('AI101', 'Delhi', 'Mumbai', 5000.00, 50);

INSERT INTO flights (flight_number, source, destination, price, available_seats)
VALUES ('AI202', 'Mumbai', 'Bangalore', 4000.00, 30);

INSERT INTO flights (flight_number, source, destination, price, available_seats)
VALUES ('AI303', 'Chennai', 'Delhi', 6000.00, 0);
