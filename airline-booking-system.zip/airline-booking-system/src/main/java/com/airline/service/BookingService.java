package com.airline.service;

import com.airline.model.Booking;
import com.airline.model.Flight;
import com.airline.repository.BookingRepository;
import com.airline.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    @Autowired
    private FlightRepository flightRepo;

    @Autowired
    private BookingRepository bookingRepo;

    public String bookFlight(String username, Long flightId, int seats) {

        Flight flight = flightRepo.findById(flightId).orElseThrow();

        // TRICKY LOGIC #1: Check seat availability
        if (flight.getAvailableSeats() < seats) {
            return "Booking Failed! Only " + flight.getAvailableSeats() + " seats available.";
        }

        // TRICKY LOGIC #2: Reduce available seats
        flight.setAvailableSeats(flight.getAvailableSeats() - seats);
        flightRepo.save(flight);

        // TRICKY LOGIC #3: Auto-calculate total price
        double total = flight.getPrice() * seats;

        Booking booking = new Booking();
        booking.setUsername(username);
        booking.setFlightNumber(flight.getFlightNumber());
        booking.setSeatsBooked(seats);
        booking.setTotalPrice(total);
        bookingRepo.save(booking);

        return "Booking Successful! Total: Rs " + total;
    }
}
