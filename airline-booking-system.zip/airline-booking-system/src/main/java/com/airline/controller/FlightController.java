package com.airline.controller;

import com.airline.model.Flight;
import com.airline.repository.BookingRepository;
import com.airline.repository.FlightRepository;
import com.airline.service.BookingService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FlightController {

    @Autowired
    private FlightRepository flightRepo;

    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private BookingService bookingService;

    private String getUser(HttpSession session) {
        return (String) session.getAttribute("username");
    }

    // View all flights
    @GetMapping("/flights")
    public String viewFlights(HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        model.addAttribute("flights", flightRepo.findAll());
        model.addAttribute("username", getUser(session));
        return "flights";
    }

    // Show booking form for selected flight
    @GetMapping("/book/{id}")
    public String showBookForm(@PathVariable Long id,
                                HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        Flight flight = flightRepo.findById(id).orElseThrow();
        model.addAttribute("flight", flight);
        model.addAttribute("username", getUser(session));
        return "bookform";
    }

    // Process booking
    @PostMapping("/confirmbooking")
    public String confirmBooking(@RequestParam Long flightId,
                                  @RequestParam int seats,
                                  HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        String message = bookingService.bookFlight(getUser(session), flightId, seats);

        model.addAttribute("message", message);
        model.addAttribute("username", getUser(session));
        model.addAttribute("flights", flightRepo.findAll());
        return "flights";
    }

    // View my bookings only
    @GetMapping("/mybookings")
    public String myBookings(HttpSession session, Model model) {
        if (getUser(session) == null) return "redirect:/login";

        String username = getUser(session);
        model.addAttribute("bookings", bookingRepo.findByUsername(username));
        model.addAttribute("username", username);
        return "mybookings";
    }
}
