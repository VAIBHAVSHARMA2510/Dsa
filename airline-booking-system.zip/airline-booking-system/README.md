# Airline Booking System
Spring Boot MVC + Spring Data JPA + Thymeleaf

## How to Import & Run

### Option A: IntelliJ IDEA / Eclipse / STS
1. Unzip this folder.
2. Open your IDE → File → Open / Import → select the `airline-booking-system` folder
   (IDE will detect it as a Maven project via `pom.xml`).
3. Let Maven download dependencies (first time only, needs internet).
4. Edit `src/main/resources/application.properties` if your MySQL
   username/password is different from `root` / `root`.
5. Run `AirlineBookingSystemApplication.java` (right-click → Run).
6. Open browser → http://localhost:8080

### Before running — Setup MySQL
- Make sure MySQL server is running.
- The app will auto-create the `airlinedb` database and tables
  (`spring.jpa.hibernate.ddl-auto=update` + `createDatabaseIfNotExist=true`).
- To add sample login/flight data, run `database-setup.sql` in MySQL
  Workbench / CLI before or after first run.

## Login Credentials (after running database-setup.sql)
- username: `admin`   password: `admin123`
- username: `vaibhav` password: `pass123`

## Project Structure
```
src/main/java/com/airline/
├── AirlineBookingSystemApplication.java
├── controller/
│   ├── AuthController.java      (login, logout)
│   └── FlightController.java    (flights, booking, my bookings)
├── model/
│   ├── User.java
│   ├── Flight.java
│   └── Booking.java
├── repository/
│   ├── UserRepository.java
│   ├── FlightRepository.java
│   └── BookingRepository.java
└── service/
    └── BookingService.java      (seat check, deduction, price calc)

src/main/resources/
├── templates/
│   ├── login.html
│   ├── flights.html
│   ├── bookform.html
│   └── mybookings.html
└── application.properties
```

## Feature Flow
```
/login → POST → session set → /flights
/flights → click "Book Now" → /book/{id}
/book/{id} → enter seats → POST /confirmbooking
   (checks seat availability, deducts seats, calculates total)
/mybookings → shows only logged-in user's bookings
/logout → session.invalidate() → /login
```

## Tricky Logic Implemented
1. Seat availability check before booking (BookingService)
2. Seat count auto-reduced after successful booking
3. Total price auto-calculated (price × seats)
4. "Sold Out" shown in UI when seats = 0
5. My Bookings filtered by logged-in username (not all bookings)
6. Session check (redirect to login) on every protected page
